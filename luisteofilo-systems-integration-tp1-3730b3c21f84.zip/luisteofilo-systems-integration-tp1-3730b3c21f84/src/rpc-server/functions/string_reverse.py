def string_reverse(s: str):
    return s[::-1]