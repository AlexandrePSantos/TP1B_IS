def string_length(s: str):
    return len(s)